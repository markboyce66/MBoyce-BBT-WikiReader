A Pen created at CodePen.io. You can find this one at https://codepen.io/merakireal/pen/ypoLMe.

 Wikipedia Viewer is a search engine for Wikipedia entries. It shows the title, timestamp and a snippet of the search results. This is a project requirement for the FreeCodeCamp Front End Certification.